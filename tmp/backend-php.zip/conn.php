<?php
// Database connection

// Detect environment
$is_localhost = in_array($_SERVER['REMOTE_ADDR'], ['127.0.0.1', '::1']) || $_SERVER['HTTP_HOST'] === 'localhost';

if ($is_localhost) {
    // Local XAMPP configuration
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "baypro";
} else {
    // Hostinger Production configuration
    // UPDATE THESE WITH YOUR HOSTINGER DETAILS
    $servername = "localhost";
    $username = "u502183679_partsbaypro";
    $password = "Partsbaypro123++";
    $dbname = "u502183679_baypro_db";
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>