<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once 'PHPMailer/src/Exception.php';
require_once 'PHPMailer/src/PHPMailer.php';
require_once 'PHPMailer/src/SMTP.php';

function sendAppointmentEmail($appointmentId, $data)
{
    $admin_email = "partsbayproo@gmail.com";
    $mail = new PHPMailer(true);

    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        // NOTE: It is better to move these credentials to a config file too
        $mail->Username = 'partsbayproo@gmail.com';
        $mail->Password = 'iwnx cdqi ygks fjzp';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->CharSet = 'UTF-8';

        // Prepare content
        $name = $data['name'];
        $email = $data['email'];
        $phone = $data['phone'];
        $service = $data['service_type'];
        $date = $data['appointment_date'];
        $time = $data['appointment_time'];
        $price = $data['price']; // Assuming this is passed or calculated
        $payment_id = $data['payment_id'] ?? 'N/A';
        $payment_method = $data['payment_method'] ?? 'Unknown';

        // Admin Email
        $adminSubject = "New Appointment #$appointmentId - $service";
        $adminBody = "
            <h2>New Appointment Booking #$appointmentId</h2>
            <p><strong>Customer:</strong> $name</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Phone:</strong> $phone</p>
            <p><strong>Service:</strong> $service</p>
            <p><strong>Date:</strong> $date</p>
            <p><strong>Time:</strong> $time</p>
            <p><strong>Amount:</strong> $price</p>
            <p><strong>Paid via:</strong> $payment_method</p>
            <p><strong>Payment ID:</strong> $payment_id</p>
        ";

        $mail->setFrom('noreply@partsbaypro.com', 'PartsBayPro');
        $mail->addAddress($admin_email);
        $mail->Subject = $adminSubject;
        $mail->isHTML(true);
        $mail->Body = $adminBody;
        $mail->send();

        // Customer Email
        $mail->clearAddresses();
        $customerSubject = "Appointment Confirmation #$appointmentId";
        $customerBody = "
            <h2>Appointment Confirmation #$appointmentId</h2>
            <p>Dear $name,</p>
            <p>Your appointment has been successfully booked!</p>
            <h3>Details</h3>
            <p><strong>Service:</strong> $service</p>
            <p><strong>Date:</strong> $date</p>
            <p><strong>Time:</strong> $time</p>
            <p><strong>Amount:</strong> $price</p>
            <hr>
            <p>We look forward to seeing you!</p>
            <p>Contact us at $admin_email for any queries.</p>
        ";

        $mail->addAddress($email);
        $mail->Subject = $customerSubject;
        $mail->Body = $customerBody;
        $mail->send();

        return ['success' => true];

    } catch (Exception $e) {
        error_log("Email sending failed: " . $e->getMessage());
        return ['success' => false, 'error' => $e->getMessage()];
    }
}
?>